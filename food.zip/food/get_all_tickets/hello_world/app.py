import json
import pymysql
import os
# import requests
host = 'food.cruglj0qvh1m.us-east-1.rds.amazonaws.com'
user = 'admin'
password = 'admin123'
db_name = 'food'
def lambda_handler(event, context):
    conn = pymysql.connect(host=host, user=user, passwd=password, db=db_name, connect_timeout=10)
    cursor = conn.cursor()
    cursor.callproc('all_tickets')
    row_headers = [x[0] for x in cursor.description]
    conn.commit()
    result = cursor.fetchall()
    json_data = []
    for row in result:
        json_data.append(dict(zip(row_headers, row)))
    print(json_data)
    data = json.dumps(json_data)
    print(data)
    conn.close()


    return {
        "all_tickets": json_data
    }